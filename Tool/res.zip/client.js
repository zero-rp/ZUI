﻿"use strict";
var lib = require('./modules/classes.js');
var Tcp = lib.Tcp;
var Timer = lib.Timer;
var client;//通信对象
var db;//数据库对象
var BrowserTabSelectIndex = 0;//当前选择的选择夹
var BrowserTabHead = GetByName("BrowserTabHead");//取游览框选择夹头部对象
var BrowserTab = GetByName("BrowserTab");//取游览框选择夹对象
var UrlEdit = GetByName("UrlEdit");

//网络服务
function Client(host, port) {
    Tcp.call(this);//创建TCP句柄
    this.t = new Timer;//重链定时器
    this.host = host;
    this.port = port;
    this.AutoConnect(5000);
}
Client.prototype.__proto__ = Tcp.prototype;
//自动重连
Client.prototype.AutoConnect = function AutoConnect(t) {
    var _tcp = this;
    //连接失败,自动重连 5s
    this.t.start(t, 0, function () {
        uv.getaddrinfo(_tcp.host, _tcp.port, function (erro, ip) {
            if (erro)
                this.AutoConnect();
            for (var i = 0; i < ip.length; i++) {
                if (ip[i].family == "INET") {
                    _tcp.connect(ip[i].ip, ip[i].port, _tcp.onConnect);
                    break;
                }
            }
        });
    });
};
//连接回调
Client.prototype.onConnect = function onConnect(err) {
    if (err) {
        //连接失败,自动重连 5s
        this.AutoConnect(5000);
    } else {
        //连接成功,开始接收数据
        this.readStart(this.onRead, true);
        //检测版本号
        this.CheckVersion();
    }
    return;
};
//断开连接处理
Client.prototype.onClose = function onClose() {
    Tcp.call(this);//创建TCP句柄用来连接
    this.AutoConnect(5000);
};
//接收数据处理
Client.prototype.onRead = function onRead(err, d) {
    if (err) {
        //连接中断,关闭当前连接
        this.close(this.onClose);
    }
    else if (d) {
        var data = new Buffer(d);
        switch (data.readUInt16LE(0)) {
            case 1: {
                //检测版本
                print("vvvv")
                break;
            }
            case 2: {
                //更新地址

            }
            case 3: {
                //登录
                if (data.readUInt16LE(2) == 2) {
                    //成功
                    GetByName("nickname").text = data.toString('utf8', 4);
                    GetByName("Layout_login").visible = false;
                } else {
                    MsgBox("登录失败,请检查你的帐号或密码", "错误");
                }
                break;
            }
            case 4: {
                //注册
                if (data.readUInt16LE(2) == 2) {


                } else {


                }
                break;
            }
            default:
                break;
        }
    }
};
//服务端调用
//检查版本
Client.prototype.CheckVersion = function CheckVersion() {
    var data = new Buffer(2);
    data.writeUInt16LE(1);
    this.write(data);
};
//获取升级地址
Client.prototype.GetUpdate = function GetUpdate() {
    var data = new Buffer(2);
    data.writeUInt16LE(2);
    this.write(data);
};
//登录
Client.prototype.Login = function Login(user, pass) {
    var data = new Buffer(102);
    data.writeUInt16LE(3);
    data.write(user, 2, 50);
    data.write(pass, 52, 50);
    this.write(data);
};
//注册
Client.prototype.Regin = function Regin(user, pass, email) {
    var data = new Buffer(152);
    data.writeUInt16LE(4);
    data.write(user, 2, 50);
    data.write(pass, 52, 50);
    data.write(email, 102, 50);
    this.write(data);
};
//注册
Client.prototype.Get = function Get(user, pass, email) {
    var data = new Buffer(152);
    data.writeUInt16LE(5);
    data.write(user, 2, 50);
    data.write(pass, 52, 50);
    data.write(email, 102, 50);
    this.write(data);
};

//选择夹头部的鼠标事件
function tabhead_onmouseenter(c) {
    if ((BrowserTabHead.GetItemIndex(c) + 1) / 2 != BrowserTabSelectIndex) {
        c.bkcolor = 0xEEDAE4F2;
    }
};//鼠标进入事件
function tabhead_onmouseleave(c) {
    if ((BrowserTabHead.GetItemIndex(c) + 1) / 2 != BrowserTabSelectIndex) {
        c.bkcolor = 0;
    }
};//鼠标离开事件
function tabhead_onclick(c) {
    UrlEdit.text="";
    var Index = (BrowserTabHead.GetItemIndex(c) + 1) / 2;
    if (Index != BrowserTabSelectIndex) {
        BrowserTabSelect(Index);
    }
};//鼠标单击事件
//选择标签
function BrowserTabSelect(Index) {
    var old = BrowserTabHead.GetItemAt(BrowserTabSelectIndex * 2 - 1);
    if (old)
        old.bkcolor = 0;
    var c = BrowserTabHead.GetItemAt(Index * 2 - 1);
    if (c)
        c.bkcolor = 0xFFF4F8FF;
    BrowserTabSelectIndex = Index;
    BrowserTab.selectitem = Index - 1;
    if (BrowserTabSelectIndex < BrowserTab.count && BrowserTab.count > 1) {
        UrlEdit.text = BrowserTab.GetItemAt(BrowserTabSelectIndex - 1).url;
    }
}
//添加标签
function AddBrowserTab(url) {
    var TabHead = new Control("HorizontalLayout");
    TabHead.minwidth = 60;
    TabHead.maxwidth = 170;
    TabHead.onmouseenter = tabhead_onmouseenter;
    TabHead.onmouseleave = tabhead_onmouseleave;
    TabHead.onclick = tabhead_onclick;
    var title = new Control("Label");
    title.name = "title";//设置名字,方便直接以成员方式操作
    title.align = "center";
    TabHead.Add(title);
    var clos = new Control("Button");
    clos.width = 16;
    clos.height = 16;
    clos.padding = "4,4,4,4";
    clos.normalimage = "res:img/clos.png:type='img':src='0,0,18,18'"
    clos.hotimage = "res:img/clos.png:type='img':src='0,18,18,18'"
    clos.pushedimage = "res:img/clos.png:type='img':src='0,36,18,18'"
    clos.onclick = function (c) {
        var a = c.parent;
        var i = BrowserTabHead.GetItemIndex(a);
        BrowserTabHead.GetItemAt(i + 1).clos();
        c.parent.clos();
        BrowserTab.GetItemAt((i - 1) / 2).clos();
        BrowserTabSelect(i - 2);
    }//关闭标签
    TabHead.Add(clos);
    BrowserTabHead.AddAt(TabHead, BrowserTabHead.count - 2);//添加到父控件
    //添加标签分割条
    var fg = new Control("NULL");
    fg.width = 1;
    fg.bkcolor = 0xFFB2BCCB;
    BrowserTabHead.AddAt(fg, BrowserTabHead.count - 2);
    var Browser = new Control("Browser");
    BrowserTab.AddAt(Browser, BrowserTab.count - 1);
    Browser.newwindow = function (c, t, url) {
        return AddBrowserTab(url);
    };//打开新窗口事件
    Browser.titlechanged = function (c, t) {
        BrowserTabHead.GetItemAt(BrowserTab.GetItemIndex(c) * 2 + 1).GetItemName("title").text = t;
    };//标题被改变事件
    Browser.urlchanged = function (c, u) {
        if (c.visible) {
            UrlEdit.text = u;
        }
    };//url被改变事件
    Browser.loader = function (c, u) {


        print(u);
    };//url加载事件
    
    Browser.url = url;//最后加载url
    BrowserTabSelect(BrowserTab.count - 1);
    return Browser;
}
//过滤URL


//事件挂接开始
BrowserTabHead.GetItemName("AddTab").onmouseenter = tabhead_onmouseenter;
BrowserTabHead.GetItemName("AddTab").onmouseleave = tabhead_onmouseleave;
BrowserTabHead.GetItemName("AddTab").onclick = tabhead_onclick;
//负责调整浮动控件
GetByName("window_main").onsize = function (c, w, h) {
    GetByName("leftswitch").top = h / 2 - 25;
}
GetByName("info").onsize = function (c, w, h) {
    GetByName("leftswitch").left = w + 3;
}
//这个事件负责控制左边栏
GetByName("leftswitch").onclick = function (c) {
    var visible = !GetByName("info").visible;
    GetByName("info").visible = visible;
    GetByName("infoSplitter").visible = visible;
    if (visible) {
        GetByName("leftswitch").left = GetByName("info").width + 3;
    } else {
        c.left = 0;
    }
}
//登录按钮回调
GetByName("login").onclick = function (c) {
    var user = GetByName("username").text;
    var pass = GetByName("password").text;
    if (!user)
        MsgBox("请输入帐号", "错误");
    else if (!pass)
        MsgBox("请输入密码", "错误");
    else if (user.length > 49 || user.length < 6)
        MsgBox("帐号长度为6至49位", "错误");
    else if (pass.length > 49 || pass.length < 6)
        MsgBox("密码长度为6至49位", "错误");
    client.Login(user, pass);

}
//确认注册按钮回调
GetByName("regin_ok").onclick = function (c) {
    var user = GetByName("username").text;
    var name = GetByName("nickname").text;
    var pass = GetByName("password").text;
    var rpass = GetByName("rpassword").text;
    var email = GetByName("email").text;
    var email_reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;

    if (!user)
        MsgBox("请输入帐号", "错误");
    else if (!name)
        MsgBox("请输入昵称", "错误");
    else if (!pass)
        MsgBox("请输入密码", "错误");
    else if (!rpass)
        MsgBox("请再次输入密码", "错误");
    else if (!email)
        MsgBox("请输入邮箱", "错误");
    else if (user.length > 49 || user.length < 6)
        MsgBox("帐号长度为6至49位", "错误");
    else if (pass.length > 49 || pass.length < 6)
        MsgBox("密码长度为6至49位", "错误");
    else if (name.length > 49 || name.length < 2)
        MsgBox("昵称长度为2至49位", "错误");
    else if (rpass!=pass)
        MsgBox("两次输入的密码不同,请重新输入", "错误");
    else if (!email_reg.test(email)) {
        MsgBox('请输入正确的邮件地址!', "错误");
        myreg.focus();
    }
    else
        client.Login(user, pass);
}
//注册按钮回调
GetByName("regin").onclick = function (c) {
    GetByName("email_l").visible = true;
    GetByName("rpassword_l").visible = true;
    GetByName("nickname_l").visible = true;
    GetByName("regin_ok").visible = true;
    GetByName("regin_back").visible = true;
    GetByName("login").visible = false;
    GetByName("regin").visible = false;
}
//返回登录按钮回调
GetByName("regin_back").onclick = function (c) {
    GetByName("email_l").visible = false;
    GetByName("rpassword_l").visible = false;
    GetByName("nickname_l").visible = false;
    GetByName("regin_ok").visible = false;
    GetByName("regin_back").visible = false;
    GetByName("login").visible = true;
    GetByName("regin").visible = true;
}
//控制按钮回调
GetByName("WindowCtl_min").onclick = function (c) { c.root.SetWindowMin(); };//设置最小化按钮回调
GetByName("WindowCtl_max").onclick = function (c) { if (c.selected) { c.root.SetWindowMax() } else { c.root.SetWindowRestor() }; };//设置最大化按钮回调
GetByName("WindowCtl_clos").onclick = function (c) { exit(); };//设置关闭按钮回调
//初始化代码

//打开数据库
db = sqlite.open("data.db", "1234");
//初始化操作
sqlite.exec(db, "create table if not exists list(id int , url text );");



//打开默认页
//AddBrowserTab("http://www.59or.com/");
AddBrowserTab("http://www.hao123.com/")

//连接服务器45
client = new Client("localhost", "7000");



